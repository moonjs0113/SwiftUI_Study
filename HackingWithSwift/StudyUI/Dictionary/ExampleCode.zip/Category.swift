//
//  Category.swift
//  StudyUI
//
//  Created by Moon Jongseek on 2022/04/29.
//

import Foundation

struct TitleCategory: Hashable {
    var name: String
    var childCategory: [Category]?
    var uiComponent: [UIComponent]?
}

struct Category: Hashable {
    var name: String
    var childTitleCategory: [TitleCategory]
}

struct UIComponent: Hashable {
    var name: String
    var script: String
    var url: URL?
}

let swiftUICategory: Category = Category(name: "SwiftUI",
                                         childTitleCategory: [
                                            TitleCategory(name: "View Containers",
                                                     childCategory: [
                                                        Category(name: "Layout Containers",
                                                                 childTitleCategory: [
                                                                    TitleCategory(name: "Stack",
                                                                                  uiComponent: [
                                                                                UIComponent(name: "VStack",
                                                                                            script: "A view that arranges its children in a vertical line."),
                                                                                UIComponent(name: "HStack",
                                                                                            script: "A view that arranges its children in a horizontal line."),
                                                                                UIComponent(name: "ZStack",
                                                                                            script: "A view that overlays its children, aligning them in both axes.")
                                                                             ])
                                                                 ]),
                                                        Category(name: "Collection Containers",
                                                                 childTitleCategory: [
                                                                    
                                                                 ]),
                                                        Category(name: "Presentation Containers",
                                                                 childTitleCategory: [
                                                                    
                                                                 ])
                                                     ]),
                                            TitleCategory(name: "User Interface Elements",
                                                     childCategory: [
                                                        
                                                     ])
                                         ])
